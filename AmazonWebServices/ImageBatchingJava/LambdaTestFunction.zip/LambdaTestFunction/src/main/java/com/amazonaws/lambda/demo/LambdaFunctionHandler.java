package com.amazonaws.lambda.demo;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.IOException;

import java.util.stream.Collectors;
public class LambdaFunctionHandler implements RequestStreamHandler{

    @Override
    public void handleRequest(InputStream input , OutputStream outputStream, Context context) throws IOException {
        
    	BufferedReader textReader = new BufferedReader(new InputStreamReader(input));
    	
    	String contents = textReader.lines().collect(Collectors.joining("\n"));
    	context.getLogger().log("Input: " + input.toString());
        
        // TODO: implement your handler
    	OutputStreamWriter writter = new OutputStreamWriter(outputStream);
    	writter.write(contents);
    	writter.close();
    }

}
